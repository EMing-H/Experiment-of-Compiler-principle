GRAM = {} #存储文法
LR_CLOSURE = {} #存储项目集族
FA_TRANS = {} #存储自动机
def init(strGram) : #将给定文法转换为字典存储
    head = strGram.split('->')[0]
    tail = strGram.split('->')[1]
    if (head in GRAM.keys()) == False :
        GRAM[head] = []
        GRAM[head].append(tail)
    else :
        GRAM[head].append(tail)
def addDictDimen(dic, key_a, key_b, val): #借助二维字典构建优先关系矩阵，外层字典key与内层字典key的关系为内层字典的value
    if key_a in dic:
        dic[key_a].update({key_b: val})
    else:
        dic.update({key_a:{key_b: val}})
def Struc_LR_CLOSURE(dic,Clo_list) : #根据求得的项目集闭包创建项目集族
    Clo_list.sort()
    state = [k for k, v in dic.items() if v == Clo_list]
    if len(state) == 0:
        dic[max(dic) + 1] = Clo_list
def Move_Struc_LR(LR_CLOSURE,FA) : #go函数的算法和项目集族自动机的构建
    mov_str_list = {}
    for i in LR_CLOSURE :
        indexList = {}
        for j in LR_CLOSURE[i] :
            right = j.split('->')[1]
            index = int(right[-1])
            if index != len(right) -1 :
                indexList[right[index]] = []
                if right[index] not in indexList[right[index]] :
                    indexList[right[index]].append(j) #把同类输入的文法加入
        for j in indexList :
            gramlist = []
            for k in indexList[j] :
                strgram = k[:-1]
                index = int(k[-1])
                if len(strgram) == index :
                    gramlist += strgram + index
                else:
                    gramlist += Closure(strgram,int(index)+1)
            mov_str_list[j] = gramlist
            addDictDimen(FA,i,j,mov_str_list[j])
    for i in mov_str_list :
        Struc_LR_CLOSURE(LR_CLOSURE,mov_str_list[i])
def Closure(strgram,index) : #计算项目集闭包
    list_Clo = []
    list_Clo.append(strgram + str(index))
    strright = strgram.split('->')[1]
    if len(strright) == index :
        return  list_Clo
    if strright[index].isupper() :
        for i in GRAM[strright[index]] :
            if i[0] != strright[index] :
                list_Clo += Closure(strright[index]+'->'+str(i),0)
            else:
                list_Clo += [strright[index] +'->'+str(i)+'0']
    list_Clo = list(set(list_Clo))
    list_Clo.sort()
    return list_Clo
def Update_FA(LR,FA) : #对初步得到的项目集族自动机的格式进行调整
    for i in FA :
        for j in FA[i] :
            for k in LR :
                if FA[i][j] == LR[k] :
                    FA[i][j] = k
def printall(LR_CLOSURE,FA_TRANS) : #打印LR(0)项目集族和自动机转换函数
    print('该文法的LR(0)项目集族为(每个文法后面的数字为待处理部分的初始位置字符的下标)：')
    for i in LR_CLOSURE :
        print('LR(0)项目集族',i,':',LR_CLOSURE[i])
    for i in FA_TRANS:
        for j in FA_TRANS[i]:
            print('f(', i, ',', j, ')=', FA_TRANS[i][j])
def main() :
    gram = []
    print('请输入文法(以#结束)：')
    while (1):
        strgram = input()
        if strgram[-1] == '#':
            gram.append(strgram[:-1])
            break
        else:
            gram.append(strgram)
    for i in gram :
        init(i)
    LR_CLOSURE[0] = Closure(gram[0],0)
    for i in range(10) :
        Move_Struc_LR(LR_CLOSURE,FA_TRANS)
    Update_FA(LR_CLOSURE,FA_TRANS)
    printall(LR_CLOSURE,FA_TRANS)
if __name__=="__main__" :
    main()
# S'->S
# S->aAcBe
# A->b
# A->Ab
# B->d#